package uz.aman.aman_escrow_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
