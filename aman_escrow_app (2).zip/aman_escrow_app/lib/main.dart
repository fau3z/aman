import 'package:flutter/material.dart';
import 'core/theme/app_theme.dart';

// Screens
import 'presentation/screens/onboarding_screen.dart';
import 'presentation/screens/auth_screen.dart';
import 'presentation/screens/home_screen.dart';
import 'presentation/screens/deal_details_screen.dart';
import 'presentation/screens/create_deal_screen.dart';
import 'presentation/screens/deposit_screen.dart';
import 'presentation/screens/dispute_screen.dart';
import 'presentation/screens/profile_screen.dart';
import 'presentation/screens/settings_screen.dart';
import 'presentation/screens/support_screen.dart';

void main() {
  runApp(const AmanApp());
}

class AmanApp extends StatelessWidget {
  const AmanApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aman Escrow',
      theme: AmanTheme.light(),
      darkTheme: AmanTheme.dark(),
      themeMode: ThemeMode.system,
      debugShowCheckedModeBanner: false,
      initialRoute: '/onboarding',
      routes: {
        '/onboarding': (context) => const OnboardingScreen(),
        '/auth': (context) => const AuthScreen(),
        '/home': (context) => const HomeScreen(),
        '/deal-details': (context) => const DealDetailsScreen(),
        '/create-deal': (context) => const CreateDealScreen(),
        '/deposit': (context) => const DepositScreen(),
        '/dispute': (context) => const DisputeScreen(),
        '/profile': (context) => const ProfileScreen(),
        '/settings': (context) => const SettingsScreen(),
        '/support': (context) => const SupportScreen(),
      },
    );
  }
}

