import 'package:flutter/material.dart';

class AmanTheme {
  static const _lightColorScheme = ColorScheme(
    brightness: Brightness.light,
    primary: Color(0xFF2563EB),       // Blue 600
    onPrimary: Colors.white,
    primaryContainer: Color(0xFFDBE2FF),
    onPrimaryContainer: Color(0xFF001A41),
    secondary: Color(0xFF34D399),     // Green 400
    onSecondary: Colors.white,
    secondaryContainer: Color(0xFFD9F9E9),
    onSecondaryContainer: Color(0xFF002111),
    tertiary: Color(0xFFF59E0B),      // Amber 500
    onTertiary: Colors.white,
    tertiaryContainer: Color(0xFFFFDDB2),
    onTertiaryContainer: Color(0xFF2B1700),
    error: Color(0xFFEF4444),         // Red 500
    onError: Colors.white,
    errorContainer: Color(0xFFFFDAD6),
    onErrorContainer: Color(0xFF410002),
    surface: Color(0xFFFCFCFF),
    onSurface: Color(0xFF1E1B1E),
    surfaceContainerHighest: Color(0xFFE1E1EC),
    onSurfaceVariant: Color(0xFF45464F),
    outline: Color(0xFF757780),
    outlineVariant: Color(0xFFC5C6D0),
    shadow: Color(0xFF000000),
    scrim: Color(0xFF000000),
    inverseSurface: Color(0xFF313034),
    onInverseSurface: Color(0xFFF3EFF4),
    inversePrimary: Color(0xFFB3C5FF),
    surfaceTint: Color(0xFF2563EB),
  );

  static const _darkColorScheme = ColorScheme(
    brightness: Brightness.dark,
    primary: Color(0xFF93B5FF),
    onPrimary: Color(0xFF002B74),
    primaryContainer: Color(0xFF0040A1),
    onPrimaryContainer: Color(0xFFDBE2FF),
    secondary: Color(0xFF20B37A),
    onSecondary: Color(0xFF003825),
    secondaryContainer: Color(0xFF00513A),
    onSecondaryContainer: Color(0xFFD9F9E9),
    tertiary: Color(0xFFFFB94D),
    onTertiary: Color(0xFF462900),
    tertiaryContainer: Color(0xFF644100),
    onTertiaryContainer: Color(0xFFFFDDB2),
    error: Color(0xFFFFB4AB),
    onError: Color(0xFF690005),
    errorContainer: Color(0xFF93000A),
    onErrorContainer: Color(0xFFFFDAD6),
    surface: Color(0xFF141316),
    onSurface: Color(0xFFE5E1E6),
    surfaceContainerHighest: Color(0xFF45464F),
    onSurfaceVariant: Color(0xFFC5C6D0),
    outline: Color(0xFF8F909A),
    outlineVariant: Color(0xFF45464F),
    shadow: Color(0xFF000000),
    scrim: Color(0xFF000000),
    inverseSurface: Color(0xFFE5E1E6),
    onInverseSurface: Color(0xFF313034),
    inversePrimary: Color(0xFF2563EB),
    surfaceTint: Color(0xFF93B5FF),
  );

  static ThemeData light() {
    return ThemeData(
      colorScheme: _lightColorScheme,
      useMaterial3: true,
      textTheme: _textTheme,
      appBarTheme: _appBarTheme(_lightColorScheme),
      cardTheme: _cardTheme(),
      elevatedButtonTheme: _elevatedButtonTheme(_lightColorScheme),
      outlinedButtonTheme: _outlinedButtonTheme(_lightColorScheme),
      textButtonTheme: _textButtonTheme(_lightColorScheme),
      inputDecorationTheme: _inputDecorationTheme(_lightColorScheme),
      scaffoldBackgroundColor: _lightColorScheme.surface,
      dialogTheme: _dialogTheme(_lightColorScheme),
    );
  }

  static ThemeData dark() {
    return ThemeData(
      colorScheme: _darkColorScheme,
      useMaterial3: true,
      textTheme: _textTheme,
      appBarTheme: _appBarTheme(_darkColorScheme),
      cardTheme: _cardTheme(),
      elevatedButtonTheme: _elevatedButtonTheme(_darkColorScheme),
      outlinedButtonTheme: _outlinedButtonTheme(_darkColorScheme),
      textButtonTheme: _textButtonTheme(_darkColorScheme),
      inputDecorationTheme: _inputDecorationTheme(_darkColorScheme),
      scaffoldBackgroundColor: _darkColorScheme.surface,
      dialogTheme: _dialogTheme(_darkColorScheme),
    );
  }

  static final _textTheme = TextTheme(
    displayLarge: TextStyle(fontSize: 57, fontWeight: FontWeight.bold),
    displayMedium: TextStyle(fontSize: 45, fontWeight: FontWeight.bold),
    displaySmall: TextStyle(fontSize: 36, fontWeight: FontWeight.bold),
    headlineLarge: TextStyle(fontSize: 32, fontWeight: FontWeight.bold),
    headlineMedium: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
    headlineSmall: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
    titleLarge: TextStyle(fontSize: 22, fontWeight: FontWeight.w600),
    titleMedium: TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
    titleSmall: TextStyle(fontSize: 14, fontWeight: FontWeight.w600),
    bodyLarge: TextStyle(fontSize: 16, fontWeight: FontWeight.normal),
    bodyMedium: TextStyle(fontSize: 14, fontWeight: FontWeight.normal),
    bodySmall: TextStyle(fontSize: 12, fontWeight: FontWeight.normal),
    labelLarge: TextStyle(fontSize: 14, fontWeight: FontWeight.w500),
    labelMedium: TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
    labelSmall: TextStyle(fontSize: 11, fontWeight: FontWeight.w500),
  );

  static AppBarTheme _appBarTheme(ColorScheme colorScheme) {
    return AppBarTheme(
      backgroundColor: colorScheme.surface,
      foregroundColor: colorScheme.onSurface,
      elevation: 0,
      centerTitle: true,
      titleTextStyle: _textTheme.titleLarge?.copyWith(
        color: colorScheme.onSurface,
      ),
    );
  }

  static CardTheme _cardTheme() {
    return const CardTheme(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.all(Radius.circular(16)),
      ),
    );
  }

  static ElevatedButtonThemeData _elevatedButtonTheme(ColorScheme colorScheme) {
    return ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        elevation: 2,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        backgroundColor: colorScheme.primary,
        foregroundColor: colorScheme.onPrimary,
      ),
    );
  }

  static OutlinedButtonThemeData _outlinedButtonTheme(ColorScheme colorScheme) {
    return OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        side: BorderSide(color: colorScheme.outline),
        foregroundColor: colorScheme.primary,
      ),
    );
  }

  static TextButtonThemeData _textButtonTheme(ColorScheme colorScheme) {
    return TextButtonThemeData(
      style: TextButton.styleFrom(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        foregroundColor: colorScheme.primary,
      ),
    );
  }

  static InputDecorationTheme _inputDecorationTheme(ColorScheme colorScheme) {
    return InputDecorationTheme(
      filled: true,
      fillColor: colorScheme.surfaceContainerHighest.withOpacity(0.3),
      contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide.none,
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: colorScheme.outline.withOpacity(0.3)),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: colorScheme.primary, width: 2),
      ),
      errorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: colorScheme.error),
      ),
      focusedErrorBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: BorderSide(color: colorScheme.error, width: 2),
      ),
      errorStyle: TextStyle(color: colorScheme.error),
    );
  }

  static DialogTheme _dialogTheme(ColorScheme colorScheme) {
    return DialogTheme(
      backgroundColor: colorScheme.surface,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(24),
      ),
    );
  }
}
