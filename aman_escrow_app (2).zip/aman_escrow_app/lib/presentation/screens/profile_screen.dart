import 'package:flutter/material.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Mock user data
    final Map<String, dynamic> userData = {
      'name': 'Фархад Алимов',
      'phone': '+998 90 123 45 67',
      'email': 'farkhad.alimov@gmail.com',
      'rating': 4.9,
      'dealCount': 15,
      'successfulDeals': 14,
      'disputedDeals': 1,
      'joinDate': 'Май 2025',
      'verified': true,
      'balance': '5 750 000',
      'escrowFunds': '10 500 000',
    };

    final List<Map<String, dynamic>> activityItems = [
      {
        'title': 'Сделка завершена',
        'description': 'Покупка Samsung Galaxy S22',
        'date': '12.07.2025',
        'amount': '+8 200 000 UZS',
        'isPositive': true,
      },
      {
        'title': 'Пополнение счета',
        'description': 'Через банковскую карту',
        'date': '10.07.2025',
        'amount': '+5 000 000 UZS',
        'isPositive': true,
      },
      {
        'title': 'Средства заблокированы',
        'description': 'Покупка iPhone 13 Pro',
        'date': '08.07.2025',
        'amount': '-10 500 000 UZS',
        'isPositive': false,
      },
      {
        'title': 'Вывод средств',
        'description': 'На карту 8600 **** **** 1234',
        'date': '05.07.2025',
        'amount': '-3 000 000 UZS',
        'isPositive': false,
      },
    ];

    return Scaffold(
      body: DefaultTabController(
        length: 2,
        child: NestedScrollView(
          headerSliverBuilder: (BuildContext context, bool innerBoxIsScrolled) {
            return <Widget>[
              SliverAppBar(
                expandedHeight: 200.0,
                floating: false,
                pinned: true,
                flexibleSpace: FlexibleSpaceBar(
                  background: _buildProfileHeader(context, userData),
                ),
              ),
              SliverPersistentHeader(
                delegate: _SliverAppBarDelegate(
                  TabBar(
                    tabs: [
                      Tab(text: 'Профиль'),
                      Tab(text: 'Активность'),
                    ],
                    labelColor: Theme.of(context).colorScheme.primary,
                    unselectedLabelColor: Theme.of(context).colorScheme.onSurfaceVariant,
                    indicatorColor: Theme.of(context).colorScheme.primary,
                    indicatorWeight: 3,
                  ),
                ),
                pinned: true,
              ),
            ];
          },
          body: TabBarView(
            children: [
              _buildProfileTab(context, userData),
              _buildActivityTab(context, activityItems),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProfileHeader(BuildContext context, Map<String, dynamic> userData) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Theme.of(context).colorScheme.primary,
            Theme.of(context).colorScheme.primaryContainer,
          ],
        ),
      ),
      padding: const EdgeInsets.fromLTRB(16, 40, 16, 16),
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircleAvatar(
              radius: 40,
              backgroundColor: Theme.of(context).colorScheme.surface,
              child: Text(
                userData['name'].substring(0, 1),
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  color: Theme.of(context).colorScheme.primary,
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  userData['name'],
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.onPrimary,
                  ),
                ),
                if (userData['verified']) ...[
                  const SizedBox(width: 8),
                  Icon(
                    Icons.verified,
                    color: Theme.of(context).colorScheme.onPrimary,
                    size: 20,
                  ),
                ],
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.star,
                  size: 16,
                  color: Colors.amber,
                ),
                const SizedBox(width: 4),
                Text(
                  '${userData['rating']} • ${userData['dealCount']} сделок',
                  style: TextStyle(
                    fontSize: 14,
                    color: Theme.of(context).colorScheme.onPrimary.withOpacity(0.8),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildProfileTab(BuildContext context, Map<String, dynamic> userData) {
    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        // Balance cards
        _buildBalanceCard(context, userData),
        const SizedBox(height: 24),
        
        // Personal info section
        _buildSectionTitle(context, 'Личные данные'),
        Card(
          margin: EdgeInsets.zero,
          child: Column(
            children: [
              _buildInfoItem(context, 'Имя', userData['name']),
              const Divider(height: 1),
              _buildInfoItem(context, 'Телефон', userData['phone']),
              const Divider(height: 1),
              _buildInfoItem(context, 'Email', userData['email']),
              const Divider(height: 1),
              _buildInfoItem(
                context, 
                'Дата регистрации', 
                userData['joinDate'],
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        
        // Statistics section
        _buildSectionTitle(context, 'Статистика'),
        Card(
          margin: EdgeInsets.zero,
          child: Column(
            children: [
              _buildStatItem(
                context,
                'Успешных сделок',
                userData['successfulDeals'].toString(),
                Icons.check_circle,
                Colors.green,
              ),
              const Divider(height: 1),
              _buildStatItem(
                context,
                'Споров',
                userData['disputedDeals'].toString(),
                Icons.gavel,
                Colors.orange,
              ),
              const Divider(height: 1),
              _buildStatItem(
                context,
                'Рейтинг',
                '${userData['rating']} / 5.0',
                Icons.star,
                Colors.amber,
              ),
            ],
          ),
        ),
        const SizedBox(height: 24),
        
        // Account options
        _buildSectionTitle(context, 'Настройки аккаунта'),
        Card(
          margin: EdgeInsets.zero,
          child: Column(
            children: [
              _buildMenuOption(
                context,
                'Изменить профиль',
                Icons.edit,
                () {
                  // Handle edit profile
                },
              ),
              const Divider(height: 1),
              _buildMenuOption(
                context,
                'Безопасность',
                Icons.security,
                () {
                  // Handle security settings
                },
              ),
              const Divider(height: 1),
              _buildMenuOption(
                context,
                'Уведомления',
                Icons.notifications,
                () {
                  // Handle notifications settings
                },
              ),
              const Divider(height: 1),
              _buildMenuOption(
                context,
                'Настройки',
                Icons.settings,
                () {
                  Navigator.pushNamed(context, '/settings');
                },
              ),
              const Divider(height: 1),
              _buildMenuOption(
                context,
                'Служба поддержки',
                Icons.headset_mic,
                () {
                  Navigator.pushNamed(context, '/support');
                },
              ),
              const Divider(height: 1),
              _buildMenuOption(
                context,
                'Выйти',
                Icons.exit_to_app,
                () {
                  Navigator.pushNamedAndRemoveUntil(
                    context, 
                    '/auth', 
                    (route) => false,
                  );
                },
                color: Theme.of(context).colorScheme.error,
              ),
            ],
          ),
        ),
        const SizedBox(height: 32),
      ],
    );
  }

  Widget _buildActivityTab(BuildContext context, List<Map<String, dynamic>> activities) {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: activities.length,
      itemBuilder: (context, index) {
        final activity = activities[index];
        return Card(
          margin: const EdgeInsets.only(bottom: 12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 48,
                  height: 48,
                  decoration: BoxDecoration(
                    color: activity['isPositive']
                        ? Colors.green.withOpacity(0.1)
                        : Colors.red.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: Icon(
                    activity['isPositive'] ? Icons.add : Icons.remove,
                    color: activity['isPositive'] ? Colors.green : Colors.red,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        activity['title'],
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        activity['description'],
                        style: TextStyle(
                          fontSize: 14,
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        activity['date'],
                        style: TextStyle(
                          fontSize: 12,
                          color: Theme.of(context).colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  activity['amount'],
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: activity['isPositive'] ? Colors.green : Colors.red,
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildBalanceCard(BuildContext context, Map<String, dynamic> userData) {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.account_balance_wallet,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Ваши средства',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.surfaceContainerHighest.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Доступно',
                          style: TextStyle(
                            fontSize: 12,
                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${userData['balance']} UZS',
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Container(
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.primaryContainer.withOpacity(0.5),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'В сделках',
                          style: TextStyle(
                            fontSize: 12,
                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '${userData['escrowFunds']} UZS',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Theme.of(context).colorScheme.primary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: SizedBox(
                    height: 40,
                    child: ElevatedButton(
                      onPressed: () {
                        Navigator.pushNamed(context, '/deposit');
                      },
                      child: const Text('Пополнить'),
                    ),
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: SizedBox(
                    height: 40,
                    child: OutlinedButton(
                      onPressed: () {
                        // Handle withdraw funds
                      },
                      child: const Text('Вывести'),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: Theme.of(context).colorScheme.secondary,
        ),
      ),
    );
  }

  Widget _buildInfoItem(BuildContext context, String label, String value) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatItem(
    BuildContext context,
    String label,
    String value,
    IconData icon,
    Color iconColor,
  ) {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Icon(
            icon,
            color: iconColor,
            size: 20,
          ),
          const SizedBox(width: 16),
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMenuOption(
    BuildContext context,
    String title,
    IconData icon,
    VoidCallback onTap, {
    Color? color,
  }) {
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        child: Row(
          children: [
            Icon(
              icon,
              color: color ?? Theme.of(context).colorScheme.onSurfaceVariant,
              size: 24,
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 16,
                  color: color,
                ),
              ),
            ),
            Icon(
              Icons.chevron_right,
              color: Theme.of(context).colorScheme.onSurfaceVariant,
              size: 24,
            ),
          ],
        ),
      ),
    );
  }
}

class _SliverAppBarDelegate extends SliverPersistentHeaderDelegate {
  _SliverAppBarDelegate(this._tabBar);

  final TabBar _tabBar;

  @override
  double get minExtent => _tabBar.preferredSize.height;
  @override
  double get maxExtent => _tabBar.preferredSize.height;

  @override
  Widget build(
    BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(
      color: Theme.of(context).colorScheme.surface,
      child: _tabBar,
    );
  }

  @override
  bool shouldRebuild(_SliverAppBarDelegate oldDelegate) {
    return false;
  }
}
