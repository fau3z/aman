import 'package:flutter/material.dart';

class DealDetailsScreen extends StatefulWidget {
  const DealDetailsScreen({super.key});

  @override
  State<DealDetailsScreen> createState() => _DealDetailsScreenState();
}

class _DealDetailsScreenState extends State<DealDetailsScreen> {
  // Mock deal data
  final Map<String, dynamic> _dealData = {
    'id': 'D-12345',
    'title': 'Покупка iPhone 13 Pro',
    'description':
        'iPhone 13 Pro, цвет: Sierra Blue, 256GB. Новый, запечатанный. Гарантия 1 год.',
    'seller': {
      'name': 'Акмаль Сайдуллаев',
      'rating': 4.8,
      'phone': '+998 90 123 45 67',
      'dealCount': 15,
    },
    'buyer': {
      'name': 'Вы',
      'rating': 4.9,
      'phone': '+998 90 987 65 43',
      'dealCount': 8,
    },
    'status': 'Ожидание оплаты',
    'amount': '10 500 000 UZS',
    'creationDate': '15.07.2025',
    'timeline': [
      {
        'status': 'Сделка создана',
        'date': '15.07.2025 10:30',
        'completed': true,
      },
      {
        'status': 'Ожидание оплаты',
        'date': 'В процессе',
        'completed': false,
      },
      {
        'status': 'Ожидание доставки',
        'date': '-',
        'completed': false,
      },
      {
        'status': 'Получено покупателем',
        'date': '-',
        'completed': false,
      },
      {
        'status': 'Сделка завершена',
        'date': '-',
        'completed': false,
      },
    ],
  };

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Сделка ${_dealData['id']}'),
        actions: [
          IconButton(
            icon: const Icon(Icons.more_vert),
            onPressed: () {
              _showOptionsBottomSheet(context);
            },
          ),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Deal card
            _buildDealSummaryCard(),
            
            const SizedBox(height: 24),
            
            // Timeline section
            Text(
              'Статус сделки',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 16),
            _buildTimeline(),
            
            const SizedBox(height: 24),
            
            // Parties section
            Text(
              'Участники сделки',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 16),
            _buildPartiesCard(),
            
            const SizedBox(height: 24),
            
            // Description section
            Text(
              'Описание сделки',
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: 8),
            Text(_dealData['description']),
            
            const SizedBox(height: 32),
            
            // Action buttons
            _buildActionButtons(),
            
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }

  Widget _buildDealSummaryCard() {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _dealData['title'],
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Сумма',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _dealData['amount'],
                      style: Theme.of(context).textTheme.titleMedium!.copyWith(
                            fontWeight: FontWeight.bold,
                          ),
                    ),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Text(
                      'Дата создания',
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _dealData['creationDate'],
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: _getStatusColor(_dealData['status']).withOpacity(0.1),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    _getStatusIcon(_dealData['status']),
                    size: 16,
                    color: _getStatusColor(_dealData['status']),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    _dealData['status'],
                    style: TextStyle(
                      color: _getStatusColor(_dealData['status']),
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTimeline() {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: List.generate(
            _dealData['timeline'].length,
            (index) => _buildTimelineItem(
              _dealData['timeline'][index],
              index,
              _dealData['timeline'].length,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTimelineItem(
      Map<String, dynamic> item, int index, int totalItems) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Column(
          children: [
            Container(
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: item['completed']
                    ? Theme.of(context).colorScheme.primary
                    : Theme.of(context).colorScheme.surfaceContainerHighest,
                border: Border.all(
                  color: item['completed']
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).colorScheme.outline,
                  width: 2,
                ),
              ),
              child: item['completed']
                  ? Icon(
                      Icons.check,
                      size: 16,
                      color: Theme.of(context).colorScheme.onPrimary,
                    )
                  : null,
            ),
            if (index < totalItems - 1)
              Container(
                width: 2,
                height: 30,
                color: item['completed']
                    ? Theme.of(context).colorScheme.primary
                    : Theme.of(context).colorScheme.outline.withOpacity(0.5),
              ),
          ],
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                item['status'],
                style: Theme.of(context).textTheme.bodyMedium!.copyWith(
                      fontWeight: FontWeight.bold,
                      color: item['completed']
                          ? Theme.of(context).colorScheme.primary
                          : null,
                    ),
              ),
              const SizedBox(height: 4),
              Text(
                item['date'],
                style: Theme.of(context).textTheme.bodySmall,
              ),
              SizedBox(height: index < totalItems - 1 ? 16 : 0),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildPartiesCard() {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            _buildPartyInfo('Продавец', _dealData['seller']),
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Divider(),
            ),
            _buildPartyInfo('Покупатель', _dealData['buyer']),
          ],
        ),
      ),
    );
  }

  Widget _buildPartyInfo(String role, Map<String, dynamic> partyData) {
    return Row(
      children: [
        Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Theme.of(context).colorScheme.primaryContainer,
          ),
          child: Center(
            child: Icon(
              role == 'Продавец' ? Icons.sell : Icons.shopping_bag,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Text(
                    role,
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.secondary,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Icon(
                    Icons.star,
                    size: 14,
                    color: Colors.amber,
                  ),
                  const SizedBox(width: 2),
                  Text(
                    '${partyData['rating']}',
                    style: TextStyle(
                      fontSize: 12,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '${partyData['dealCount']} сделок',
                    style: TextStyle(
                      fontSize: 12,
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 4),
              Text(
                partyData['name'],
                style: Theme.of(context).textTheme.titleMedium,
              ),
              const SizedBox(height: 2),
              Text(
                partyData['phone'],
                style: Theme.of(context).textTheme.bodyMedium,
              ),
            ],
          ),
        ),
        IconButton(
          icon: const Icon(Icons.chat_outlined),
          onPressed: () {
            // Handle chat with party
          },
        ),
      ],
    );
  }

  Widget _buildActionButtons() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        SizedBox(
          height: 50,
          child: ElevatedButton(
            onPressed: () {
              Navigator.pushNamed(context, '/deposit');
            },
            child: const Text('Оплатить'),
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 50,
          child: OutlinedButton(
            onPressed: () {
              Navigator.pushNamed(context, '/dispute');
            },
            child: const Text('Открыть спор'),
          ),
        ),
      ],
    );
  }

  void _showOptionsBottomSheet(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (context) => Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: const Icon(Icons.chat),
              title: const Text('Чат сделки'),
              onTap: () {
                Navigator.pop(context);
                // Handle opening chat
              },
            ),
            ListTile(
              leading: const Icon(Icons.description),
              title: const Text('Детали договора'),
              onTap: () {
                Navigator.pop(context);
                // Handle showing contract details
              },
            ),
            ListTile(
              leading: const Icon(Icons.cancel),
              title: const Text('Отменить сделку'),
              onTap: () {
                Navigator.pop(context);
                // Handle cancellation
                _showCancellationDialog(context);
              },
            ),
            ListTile(
              leading: const Icon(Icons.headset_mic),
              title: const Text('Служба поддержки'),
              onTap: () {
                Navigator.pop(context);
                Navigator.pushNamed(context, '/support');
              },
            ),
          ],
        ),
      ),
    );
  }

  void _showCancellationDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Отмена сделки'),
        content: const Text(
            'Вы уверены, что хотите отменить сделку? Это действие невозможно отменить.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Нет'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Сделка отменена'),
                ),
              );
            },
            child: const Text('Да, отменить'),
          ),
        ],
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status) {
      case 'Ожидание оплаты':
        return Colors.orange;
      case 'Ожидание доставки':
        return Colors.blue;
      case 'В процессе':
        return Colors.green;
      case 'Ожидание подтверждения':
        return Colors.purple;
      default:
        return Colors.grey;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status) {
      case 'Ожидание оплаты':
        return Icons.payments_outlined;
      case 'Ожидание доставки':
        return Icons.local_shipping_outlined;
      case 'В процессе':
        return Icons.engineering_outlined;
      case 'Ожидание подтверждения':
        return Icons.pending_outlined;
      default:
        return Icons.info_outline;
    }
  }
}
