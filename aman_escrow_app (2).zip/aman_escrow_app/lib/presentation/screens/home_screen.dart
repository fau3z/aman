import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  int _currentIndex = 0;

  // Mock data for active deals
  final List<Map<String, dynamic>> _mockDeals = [
    {
      'id': 'D-12345',
      'title': 'Покупка iPhone 13 Pro',
      'seller': 'Акмаль Сайдуллаев',
      'buyer': 'Вы',
      'status': 'Ожидание оплаты',
      'amount': '10 500 000 UZS',
      'date': '15.07.2025',
      'isOutgoing': false,
    },
    {
      'id': 'D-12346',
      'title': 'Ноутбук MacBook Air',
      'seller': 'Вы',
      'buyer': 'Ольга Нигматова',
      'status': 'Ожидание доставки',
      'amount': '15 800 000 UZS',
      'date': '14.07.2025',
      'isOutgoing': true,
    },
    {
      'id': 'D-12347',
      'title': 'Разработка веб-сайта',
      'seller': 'Вы',
      'buyer': 'Улугбек Тураев',
      'status': 'В процессе',
      'amount': '8 500 000 UZS',
      'date': '10.07.2025',
      'isOutgoing': true,
    },
    {
      'id': 'D-12348',
      'title': 'Аренда офиса на 3 месяца',
      'seller': 'Ташкент Бизнес Центр',
      'buyer': 'Вы',
      'status': 'Ожидание подтверждения',
      'amount': '12 000 000 UZS',
      'date': '08.07.2025',
      'isOutgoing': false,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Мои сделки'),
        actions: [
          IconButton(
            icon: const Icon(Icons.notifications_outlined),
            onPressed: () {
              // Show notifications
              _showNotificationSnackBar(context);
            },
          ),
        ],
      ),
      body: _buildBody(),
      bottomNavigationBar: NavigationBar(
        onDestinationSelected: (int index) {
          setState(() {
            _currentIndex = index;
          });
          
          // Handle navigation based on index
          if (index == 3) { // Profile
            Navigator.pushNamed(context, '/profile');
          }
        },
        selectedIndex: _currentIndex,
        destinations: const [
          NavigationDestination(
            icon: Icon(Icons.home_outlined),
            selectedIcon: Icon(Icons.home),
            label: 'Сделки',
          ),
          NavigationDestination(
            icon: Icon(Icons.history_outlined),
            selectedIcon: Icon(Icons.history),
            label: 'История',
          ),
          NavigationDestination(
            icon: Icon(Icons.account_balance_wallet_outlined),
            selectedIcon: Icon(Icons.account_balance_wallet),
            label: 'Счёт',
          ),
          NavigationDestination(
            icon: Icon(Icons.person_outline),
            selectedIcon: Icon(Icons.person),
            label: 'Профиль',
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          Navigator.pushNamed(context, '/create-deal');
        },
        child: const Icon(Icons.add),
      ),
    );
  }

  Widget _buildBody() {
    if (_currentIndex == 0) {
      return _buildDealsTab();
    } else if (_currentIndex == 1) {
      return _buildHistoryTab();
    } else if (_currentIndex == 2) {
      return _buildWalletTab();
    } else {
      // This shouldn't be visible as we navigate to profile screen
      return const Center(child: Text('Профиль'));
    }
  }

  Widget _buildDealsTab() {
    return _mockDeals.isEmpty
        ? _buildEmptyState()
        : ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: _mockDeals.length + 1, // +1 for the balance card
            itemBuilder: (context, index) {
              if (index == 0) {
                // Balance card at the top
                return _buildBalanceCard();
              }
              final deal = _mockDeals[index - 1];
              return _buildDealCard(deal);
            },
          );
  }

  Widget _buildDealCard(Map<String, dynamic> deal) {
    Color statusColor;
    IconData statusIcon;

    // Set color and icon based on status
    switch (deal['status']) {
      case 'Ожидание оплаты':
        statusColor = Colors.orange;
        statusIcon = Icons.payments_outlined;
        break;
      case 'Ожидание доставки':
        statusColor = Colors.blue;
        statusIcon = Icons.local_shipping_outlined;
        break;
      case 'В процессе':
        statusColor = Colors.green;
        statusIcon = Icons.engineering_outlined;
        break;
      case 'Ожидание подтверждения':
        statusColor = Colors.purple;
        statusIcon = Icons.pending_outlined;
        break;
      default:
        statusColor = Colors.grey;
        statusIcon = Icons.info_outline;
    }

    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: InkWell(
        onTap: () {
          Navigator.pushNamed(context, '/deal-details');
        },
        borderRadius: BorderRadius.circular(16),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    deal['id'],
                    style: TextStyle(
                      color: Theme.of(context).colorScheme.primary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    deal['date'],
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                deal['title'],
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Продавец',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          deal['seller'],
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                  Icon(Icons.arrow_forward, color: Colors.grey),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.end,
                      children: [
                        Text(
                          'Покупатель',
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                        const SizedBox(height: 4),
                        Text(
                          deal['buyer'],
                          style: Theme.of(context).textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: statusColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Row(
                          children: [
                            Icon(statusIcon, size: 16, color: statusColor),
                            const SizedBox(width: 4),
                            Text(
                              deal['status'],
                              style: TextStyle(
                                color: statusColor,
                                fontWeight: FontWeight.w500,
                                fontSize: 12,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  Text(
                    deal['amount'],
                    style: Theme.of(context).textTheme.titleMedium!.copyWith(
                          fontWeight: FontWeight.bold,
                        ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildHistoryTab() {
    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: _mockDeals.length,
      itemBuilder: (context, index) {
        final deal = _mockDeals[index];
        return _buildDealCard(deal);
      },
    );
  }

  Widget _buildBalanceCard() {
    return Card(
      margin: const EdgeInsets.only(bottom: 16),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.account_balance_wallet,
                  color: Theme.of(context).colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Text(
                  'Баланс счёта',
                  style: TextStyle(
                    fontSize: 16,
                    color: Theme.of(context).colorScheme.onSurface,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            const Text(
              '5 750 000 UZS',
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 16),
            Text(
              'Средств в сделках: 10 500 000 UZS',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey,
              ),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/deposit');
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.white,
                  foregroundColor: Theme.of(context).colorScheme.primary,
                  elevation: 0,
                ),
                child: const Text('Пополнить'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildWalletTab() {
    return Padding(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Balance card
          _buildBalanceCard(),
          const SizedBox(height: 30),
          // Transactions section title
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Последние транзакции',
                style: Theme.of(context).textTheme.titleMedium,
              ),
              TextButton(
                onPressed: () {},
                child: const Text('Все'),
              ),
            ],
          ),
          const SizedBox(height: 10),
          // Mock transactions list
          Expanded(
            child: ListView(
              children: [
                _buildTransactionItem(
                  'Пополнение счёта',
                  '+ 2 000 000 UZS',
                  '15.07.2025',
                  Icons.account_balance_wallet,
                  Colors.green,
                ),
                _buildTransactionItem(
                  'Оплата сделки D-12345',
                  '- 10 500 000 UZS',
                  '15.07.2025',
                  Icons.shopping_bag,
                  Colors.red,
                ),
                _buildTransactionItem(
                  'Возврат средств D-11223',
                  '+ 4 250 000 UZS',
                  '12.07.2025',
                  Icons.replay,
                  Colors.green,
                ),
                _buildTransactionItem(
                  'Пополнение счёта',
                  '+ 10 000 000 UZS',
                  '10.07.2025',
                  Icons.account_balance_wallet,
                  Colors.green,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTransactionItem(
      String title, String amount, String date, IconData icon, Color color) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: color.withOpacity(0.1),
          shape: BoxShape.circle,
        ),
        child: Icon(icon, color: color),
      ),
      title: Text(title),
      subtitle: Text(date),
      trailing: Text(
        amount,
        style: TextStyle(
          fontWeight: FontWeight.bold,
          color: color,
        ),
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.business_center_outlined,
            size: 80,
            color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'У вас пока нет активных сделок',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          const SizedBox(height: 8),
          Text(
            'Нажмите кнопку "+" чтобы создать новую сделку',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),
          ElevatedButton(
            onPressed: () {
              Navigator.pushNamed(context, '/create-deal');
            },
            child: const Text('Создать сделку'),
          ),
        ],
      ),
    );
  }

  void _showNotificationSnackBar(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('У вас нет новых уведомлений'),
        behavior: SnackBarBehavior.floating,
        action: SnackBarAction(
          label: 'OK',
          onPressed: () {},
        ),
      ),
    );
  }
}
