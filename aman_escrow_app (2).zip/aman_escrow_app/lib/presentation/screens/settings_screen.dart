import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _darkMode = false;
  bool _notifications = true;
  String _language = 'Русский';
  String _currency = 'UZS';
  bool _biometric = true;
  bool _twoFactor = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Настройки')),
      body: ListView(
        children: [
          const SizedBox(height: 8),
          _buildSettingSection('Оформление'),
          SwitchListTile(
            title: const Text('Темная тема'),
            subtitle: Text(
              'Использовать темное оформление',
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                fontSize: 14,
              ),
            ),
            value: _darkMode,
            onChanged: (bool value) {
              setState(() {
                _darkMode = value;
              });
              // Здесь был бы код для изменения темы
            },
            secondary: Icon(
              _darkMode ? Icons.dark_mode : Icons.light_mode,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const Divider(),

          _buildSettingListTile(
            title: 'Язык приложения',
            subtitle: _language,
            icon: Icons.language,
            onTap: _showLanguageDialog,
          ),

          _buildSettingSection('Уведомления'),
          SwitchListTile(
            title: const Text('Уведомления'),
            subtitle: Text(
              'Push-уведомления о сделках',
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                fontSize: 14,
              ),
            ),
            value: _notifications,
            onChanged: (bool value) {
              setState(() {
                _notifications = value;
              });
            },
            secondary: Icon(
              _notifications
                  ? Icons.notifications_active
                  : Icons.notifications_off,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),

          _buildSettingSection('Финансы'),
          _buildSettingListTile(
            title: 'Валюта отображения',
            subtitle: _currency,
            icon: Icons.currency_exchange,
            onTap: _showCurrencyDialog,
          ),

          _buildSettingSection('Безопасность'),
          SwitchListTile(
            title: const Text('Биометрическая аутентификация'),
            subtitle: Text(
              'Использовать Face ID или отпечаток пальца для входа',
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                fontSize: 14,
              ),
            ),
            value: _biometric,
            onChanged: (bool value) {
              setState(() {
                _biometric = value;
              });
            },
            secondary: Icon(
              Icons.fingerprint,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),
          const Divider(),

          SwitchListTile(
            title: const Text('Двухфакторная аутентификация'),
            subtitle: Text(
              'Повышенная безопасность аккаунта',
              style: TextStyle(
                color: Theme.of(context).colorScheme.onSurfaceVariant,
                fontSize: 14,
              ),
            ),
            value: _twoFactor,
            onChanged: (bool value) {
              if (value) {
                _showTwoFactorDialog();
              } else {
                setState(() {
                  _twoFactor = value;
                });
              }
            },
            secondary: Icon(
              Icons.security,
              color: Theme.of(context).colorScheme.primary,
            ),
          ),

          _buildSettingSection('О приложении'),
          _buildSettingListTile(
            title: 'Версия приложения',
            subtitle: '1.0.0 (Build 2025071)',
            icon: Icons.info_outline,
            onTap: () {},
            showArrow: false,
          ),
          const Divider(),
          _buildSettingListTile(
            title: 'Пользовательское соглашение',
            icon: Icons.description,
            onTap: () {
              // Open terms of service
            },
          ),
          const Divider(),
          _buildSettingListTile(
            title: 'Политика конфиденциальности',
            icon: Icons.privacy_tip,
            onTap: () {
              // Open privacy policy
            },
          ),
          const SizedBox(height: 24),

          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: OutlinedButton(
              onPressed: () {
                _showClearDataDialog();
              },
              style: OutlinedButton.styleFrom(
                foregroundColor: Theme.of(context).colorScheme.error,
                side: BorderSide(color: Theme.of(context).colorScheme.error),
              ),
              child: const Text('Очистить данные приложения'),
            ),
          ),

          const SizedBox(height: 32),
        ],
      ),
    );
  }

  Widget _buildSettingSection(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 14,
          fontWeight: FontWeight.bold,
          color: Theme.of(context).colorScheme.primary,
        ),
      ),
    );
  }

  Widget _buildSettingListTile({
    required String title,
    String? subtitle,
    required IconData icon,
    required VoidCallback onTap,
    bool showArrow = true,
  }) {
    return ListTile(
      title: Text(title),
      subtitle:
          subtitle != null
              ? Text(
                subtitle,
                style: TextStyle(
                  color: Theme.of(context).colorScheme.onSurfaceVariant,
                  fontSize: 14,
                ),
              )
              : null,
      leading: Icon(icon, color: Theme.of(context).colorScheme.primary),
      trailing: showArrow ? const Icon(Icons.chevron_right) : null,
      onTap: onTap,
    );
  }

  void _showLanguageDialog() {
    final languages = ['Русский', 'O`zbek', 'English'];

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Выберите язык'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children:
                  languages.map((lang) {
                    return RadioListTile<String>(
                      title: Text(lang),
                      value: lang,
                      groupValue: _language,
                      onChanged: (String? value) {
                        if (value != null) {
                          setState(() {
                            _language = value;
                          });
                          Navigator.pop(context);
                        }
                      },
                    );
                  }).toList(),
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Отмена'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _showCurrencyDialog() {
    final currencies = ['UZS', 'USD', 'EUR'];

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Валюта отображения'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children:
                  currencies.map((currency) {
                    return RadioListTile<String>(
                      title: Text(currency),
                      value: currency,
                      groupValue: _currency,
                      onChanged: (String? value) {
                        if (value != null) {
                          setState(() {
                            _currency = value;
                          });
                          Navigator.pop(context);
                        }
                      },
                    );
                  }).toList(),
            ),
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Отмена'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  void _showTwoFactorDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Двухфакторная аутентификация'),
          content: const Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Для подключения двухфакторной аутентификации вам необходимо:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 16),
              Text('1. Подтвердить номер телефона'),
              Text('2. Установить приложение-аутентификатор'),
              Text('3. Сгенерировать и сохранить резервные коды'),
              SizedBox(height: 16),
              Text(
                'Это значительно повысит безопасность вашего аккаунта. Перейти к настройке?',
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Отмена'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('Настроить'),
              onPressed: () {
                setState(() {
                  _twoFactor = true;
                });
                Navigator.of(context).pop();

                // В реальном приложении здесь был бы переход к экрану настройки 2FA
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Двухфакторная аутентификация включена'),
                  ),
                );
              },
            ),
          ],
        );
      },
    );
  }

  void _showClearDataDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Очистить данные приложения'),
          content: const Text(
            'Вы уверены, что хотите очистить все локальные данные приложения? Это действие нельзя будет отменить. Ваши сделки и средства сохранятся, но вам придется войти в приложение заново.',
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Отмена'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Theme.of(context).colorScheme.error,
              ),
              child: const Text('Очистить'),
              onPressed: () {
                Navigator.of(context).pop();

                // Демонстрационная очистка данных
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Данные приложения очищены')),
                );

                // В реальном приложении здесь был бы код очистки данных
                // и перенаправление на экран входа
                Future.delayed(const Duration(seconds: 1), () {
                  Navigator.pushNamedAndRemoveUntil(
                    context,
                    '/auth',
                    (route) => false,
                  );
                });
              },
            ),
          ],
        );
      },
    );
  }
}
