import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class CreateDealScreen extends StatefulWidget {
  const CreateDealScreen({super.key});

  @override
  State<CreateDealScreen> createState() => _CreateDealScreenState();
}

class _CreateDealScreenState extends State<CreateDealScreen> {
  final _formKey = GlobalKey<FormState>();
  int _currentStep = 0;
  String _selectedCategory = 'Товары';
  final TextEditingController _titleController = TextEditingController();
  final TextEditingController _descriptionController = TextEditingController();
  final TextEditingController _amountController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  final List<String> _categories = [
    'Товары',
    'Услуги',
    'Недвижимость',
    'Транспорт',
    'Другое',
  ];

  @override
  void dispose() {
    _titleController.dispose();
    _descriptionController.dispose();
    _amountController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Создание сделки'),
      ),
      body: Form(
        key: _formKey,
        child: Stepper(
          type: StepperType.horizontal,
          currentStep: _currentStep,
          onStepTapped: (step) {
            setState(() {
              _currentStep = step;
            });
          },
          onStepContinue: () {
            final isLastStep = _currentStep == 2;

            if (isLastStep) {
              _submitForm();
            } else {
              setState(() {
                _currentStep += 1;
              });
            }
          },
          onStepCancel: () {
            if (_currentStep > 0) {
              setState(() {
                _currentStep -= 1;
              });
            }
          },
          steps: [
            Step(
              title: const Text('Основное'),
              content: _buildBasicInfoStep(),
              isActive: _currentStep >= 0,
            ),
            Step(
              title: const Text('Детали'),
              content: _buildDetailsStep(),
              isActive: _currentStep >= 1,
            ),
            Step(
              title: const Text('Подтверждение'),
              content: _buildConfirmationStep(),
              isActive: _currentStep >= 2,
            ),
          ],
          controlsBuilder: (context, details) {
            final isLastStep = _currentStep == 2;

            return Padding(
              padding: const EdgeInsets.only(top: 20),
              child: Row(
                children: [
                  Expanded(
                    child: ElevatedButton(
                      onPressed: details.onStepContinue,
                      child: Text(
                        isLastStep ? 'Создать сделку' : 'Далее',
                      ),
                    ),
                  ),
                  if (_currentStep > 0) ...[
                    const SizedBox(width: 12),
                    Expanded(
                      child: OutlinedButton(
                        onPressed: details.onStepCancel,
                        child: const Text('Назад'),
                      ),
                    ),
                  ],
                ],
              ),
            );
          },
        ),
      ),
    );
  }

  Widget _buildBasicInfoStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        DropdownButtonFormField<String>(
          decoration: const InputDecoration(
            labelText: 'Категория',
            prefixIcon: Icon(Icons.category),
          ),
          value: _selectedCategory,
          items: _categories
              .map((category) => DropdownMenuItem(
                    value: category,
                    child: Text(category),
                  ))
              .toList(),
          onChanged: (value) {
            if (value != null) {
              setState(() {
                _selectedCategory = value;
              });
            }
          },
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Пожалуйста, выберите категорию';
            }
            return null;
          },
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _titleController,
          decoration: const InputDecoration(
            labelText: 'Название сделки',
            prefixIcon: Icon(Icons.title),
            hintText: 'Например: Покупка iPhone 13 Pro',
          ),
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Пожалуйста, введите название сделки';
            }
            return null;
          },
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _amountController,
          decoration: const InputDecoration(
            labelText: 'Сумма сделки (UZS)',
            prefixIcon: Icon(Icons.payments),
            suffixText: 'UZS',
            hintText: 'Например: 10500000',
          ),
          keyboardType: TextInputType.number,
          inputFormatters: [
            FilteringTextInputFormatter.digitsOnly,
          ],
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Пожалуйста, введите сумму сделки';
            }
            return null;
          },
        ),
        const SizedBox(height: 16),
      ],
    );
  }

  Widget _buildDetailsStep() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        TextFormField(
          controller: _descriptionController,
          decoration: const InputDecoration(
            labelText: 'Описание сделки',
            prefixIcon: Icon(Icons.description),
            hintText:
                'Опишите товар или услугу, условия сделки, способ доставки и т.д.',
          ),
          maxLines: 5,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Пожалуйста, введите описание сделки';
            }
            return null;
          },
        ),
        const SizedBox(height: 24),
        Text(
          'Данные второй стороны',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: RadioListTile<String>(
                title: const Text('Покупатель'),
                value: 'buyer',
                groupValue: 'seller',
                onChanged: (value) {},
              ),
            ),
            Expanded(
              child: RadioListTile<String>(
                title: const Text('Продавец'),
                value: 'seller',
                groupValue: 'seller',
                onChanged: (value) {},
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        TextFormField(
          controller: _phoneController,
          decoration: const InputDecoration(
            labelText: 'Телефон контрагента',
            prefixIcon: Icon(Icons.phone),
            hintText: '+998 XX XXX XX XX',
          ),
          keyboardType: TextInputType.phone,
          validator: (value) {
            if (value == null || value.isEmpty) {
              return 'Пожалуйста, введите телефон контрагента';
            }
            return null;
          },
        ),
      ],
    );
  }

  Widget _buildConfirmationStep() {
    // Format amount with spaces
    String formattedAmount = _amountController.text.isEmpty
        ? '0'
        : _formatAmount(_amountController.text);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Проверьте данные сделки перед созданием:',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 24),
        _buildInfoRow('Категория:', _selectedCategory),
        _buildInfoRow('Название:', _titleController.text),
        _buildInfoRow('Сумма:', '$formattedAmount UZS'),
        _buildInfoRow('Ваша роль:', 'Продавец'),
        _buildInfoRow('Телефон контрагента:', _phoneController.text),
        const SizedBox(height: 16),
        const Divider(),
        const SizedBox(height: 16),
        Text(
          'Описание:',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Theme.of(context).colorScheme.secondary,
          ),
        ),
        const SizedBox(height: 8),
        Text(_descriptionController.text),
        const SizedBox(height: 24),
        const Text(
          'Комиссия сервиса: 1% от суммы сделки',
          style: TextStyle(fontStyle: FontStyle.italic),
        ),
      ],
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 150,
            child: Text(
              label,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: Theme.of(context).colorScheme.secondary,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value.isEmpty ? 'Не указано' : value,
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
        ],
      ),
    );
  }

  String _formatAmount(String amount) {
    final buffer = StringBuffer();
    for (int i = amount.length - 1, count = 0; i >= 0; i--, count++) {
      if (count > 0 && count % 3 == 0) {
        buffer.write(' ');
      }
      buffer.write(amount[i]);
    }
    return String.fromCharCodes(buffer.toString().codeUnits.reversed);
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {
      // Show loading dialog
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) => const Center(
          child: CircularProgressIndicator(),
        ),
      );

      // Simulate API call
      Future.delayed(const Duration(seconds: 2), () {
        Navigator.pop(context); // Close loading dialog
        _showSuccessDialog();
      });
    }
  }

  void _showSuccessDialog() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(
              Icons.check_circle,
              color: Theme.of(context).colorScheme.primary,
            ),
            const SizedBox(width: 8),
            const Text('Сделка создана'),
          ],
        ),
        content: const Text(
          'Сделка успешно создана! Контрагент получит уведомление о приглашении к сделке.',
        ),
        actions: [
          TextButton(
            onPressed: () {
              Navigator.pop(context);
              Navigator.pop(context);
              Navigator.pushReplacementNamed(context, '/home');
            },
            child: const Text('К списку сделок'),
          ),
        ],
      ),
    );
  }
}
