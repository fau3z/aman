import 'package:flutter/material.dart';

class SupportScreen extends StatefulWidget {
  const SupportScreen({super.key});

  @override
  State<SupportScreen> createState() => _SupportScreenState();
}

class _SupportScreenState extends State<SupportScreen> {
  final TextEditingController _messageController = TextEditingController();
  final List<Map<String, dynamic>> _messages = [];
  final List<Map<String, dynamic>> _faqItems = [
    {
      'question': 'Как работает сервис Aman Escrow?',
      'answer':
          'Aman Escrow — это сервис безопасных сделок, который выступает в качестве посредника между продавцом и покупателем. Покупатель депонирует средства, продавец доставляет товар или оказывает услугу, после подтверждения получения средства переводятся продавцу.',
    },
    {
      'question': 'Какая комиссия взимается за использование сервиса?',
      'answer':
          'Комиссия составляет 1% от суммы сделки, но не менее 10,000 UZS. Комиссия взимается только при успешном завершении сделки.',
    },
    {
      'question': 'Что делать, если возник спор между сторонами?',
      'answer':
          'В случае возникновения спора вы можете открыть его в разделе деталей сделки. Наши специалисты рассмотрят обстоятельства и вынесут решение в соответствии с условиями сервиса в течение 3 рабочих дней.',
    },
    {
      'question': 'Как вывести средства с баланса Aman?',
      'answer':
          'Средства можно вывести на банковскую карту или счет в разделе "Профиль" > "Вывести средства". Средства поступят в течение 24 часов, но обычно операция занимает не более 1 часа.',
    },
    {
      'question': 'Как пополнить баланс Aman?',
      'answer':
          'Пополнить баланс можно через банковскую карту, банковский перевод, или через платежные системы CLICK и Payme. Операция происходит мгновенно и без комиссии.',
    },
    {
      'question': 'Безопасно ли использовать сервис Aman?',
      'answer':
          'Да, Aman использует современные методы шифрования данных и проверки личности. Сервис лицензирован Центральным Банком РУз и застрахован от киберрисков.',
    },
  ];

  bool _isTyping = false;

  @override
  void initState() {
    super.initState();
    _simulateInitialBotMessage();
  }

  @override
  void dispose() {
    _messageController.dispose();
    super.dispose();
  }

  void _simulateInitialBotMessage() {
    // Add initial bot message with slight delay to simulate real-time chat
    Future.delayed(const Duration(milliseconds: 500), () {
      if (mounted) {
        setState(() {
          _messages.add({
            'text':
                'Здравствуйте! Я виртуальный помощник Aman. Чем я могу вам помочь сегодня? Вы можете выбрать один из часто задаваемых вопросов или задать свой вопрос.',
            'isUser': false,
            'time': DateTime.now(),
          });
        });
      }
    });
  }

  void _handleSendMessage() {
    if (_messageController.text.trim().isEmpty) return;

    final userMessage = _messageController.text.trim();
    setState(() {
      _messages.add({
        'text': userMessage,
        'isUser': true,
        'time': DateTime.now(),
      });
      _messageController.clear();
      _isTyping = true;
    });

    // Simulate bot response after delay
    Future.delayed(const Duration(seconds: 1), () {
      if (mounted) {
        setState(() {
          _isTyping = false;
          _messages.add({
            'text': _generateBotResponse(userMessage),
            'isUser': false,
            'time': DateTime.now(),
          });
        });
      }
    });
  }

  String _generateBotResponse(String userMessage) {
    // Simple keyword matching for demo purposes
    final lowercaseMessage = userMessage.toLowerCase();
    
    if (lowercaseMessage.contains('привет') || 
        lowercaseMessage.contains('здравствуйте')) {
      return 'Здравствуйте! Чем я могу вам помочь сегодня?';
    } else if (lowercaseMessage.contains('комиссия') ||
              lowercaseMessage.contains('стоимость') ||
              lowercaseMessage.contains('плата')) {
      return 'Комиссия сервиса Aman составляет 1% от суммы сделки, но не менее 10,000 UZS. Комиссия взимается только при успешном завершении сделки.';
    } else if (lowercaseMessage.contains('спор') || 
              lowercaseMessage.contains('проблема') ||
              lowercaseMessage.contains('конфликт')) {
      return 'В случае возникновения спора, вы можете открыть его в деталях сделки. Наши специалисты рассмотрят ситуацию в течение 3 рабочих дней. Вы также можете позвонить на горячую линию: +998 71 200 40 50.';
    } else if (lowercaseMessage.contains('оператор') || 
              lowercaseMessage.contains('человек') ||
              lowercaseMessage.contains('специалист')) {
      return 'Я могу соединить вас с оператором. Рабочие часы службы поддержки: 9:00-21:00. Хотите, чтобы оператор связался с вами?';
    } else {
      return 'Спасибо за ваш вопрос. Я передам его нашим специалистам, и они свяжутся с вами в ближайшее время. Вы также можете позвонить на нашу горячую линию: +998 71 200 40 50.';
    }
  }

  void _handleFaqTap(Map<String, dynamic> faqItem) {
    setState(() {
      _messages.add({
        'text': faqItem['question'],
        'isUser': true,
        'time': DateTime.now(),
      });
      _isTyping = true;
    });

    // Simulate bot response after delay
    Future.delayed(const Duration(milliseconds: 800), () {
      if (mounted) {
        setState(() {
          _isTyping = false;
          _messages.add({
            'text': faqItem['answer'],
            'isUser': false,
            'time': DateTime.now(),
          });
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Служба поддержки'),
        actions: [
          IconButton(
            icon: const Icon(Icons.phone),
            onPressed: () {
              // Handle call to support
              _showCallDialog();
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // FAQ section
          Container(
            padding: const EdgeInsets.symmetric(vertical: 8),
            height: 60,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              itemCount: _faqItems.length,
              itemBuilder: (context, index) {
                return Padding(
                  padding: const EdgeInsets.only(right: 8),
                  child: InkWell(
                    onTap: () => _handleFaqTap(_faqItems[index]),
                    borderRadius: BorderRadius.circular(20),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 8,
                      ),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.surfaceContainerHighest,
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Center(
                        child: Text(
                          _getFaqChipText(_faqItems[index]['question']),
                          style: TextStyle(
                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          
          const Divider(height: 1),

          // Chat area
          Expanded(
            child: _messages.isEmpty
                ? _buildEmptyState()
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 16,
                      vertical: 8,
                    ),
                    reverse: true, // Display messages from bottom to top
                    itemCount: _messages.length + (_isTyping ? 1 : 0),
                    itemBuilder: (context, index) {
                      // Show typing indicator
                      if (_isTyping && index == 0) {
                        return _buildTypingIndicator();
                      }

                      // Adjust index for typing indicator
                      final messageIndex = _isTyping ? index - 1 : index;

                      // Reverse the list to show newest messages at bottom
                      final message = _messages[_messages.length - 1 - messageIndex];
                      return _buildMessageBubble(
                        message['text'],
                        message['isUser'],
                        message['time'],
                      );
                    },
                  ),
          ),

          // Typing indicator at the bottom while typing
          if (_isTyping)
            Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 8,
              ),
              alignment: Alignment.centerLeft,
              child: const Text(
                'Виртуальный помощник печатает...',
                style: TextStyle(
                  fontSize: 12,
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),

          // Input area
          Container(
            padding: const EdgeInsets.all(8.0),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 5,
                  offset: const Offset(0, -2),
                ),
              ],
            ),
            child: Row(
              children: [
                IconButton(
                  icon: const Icon(Icons.attach_file),
                  onPressed: () {
                    // Handle attachment
                  },
                ),
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    decoration: const InputDecoration(
                      hintText: 'Введите сообщение...',
                      border: InputBorder.none,
                    ),
                    textInputAction: TextInputAction.send,
                    onSubmitted: (_) => _handleSendMessage(),
                  ),
                ),
                IconButton(
                  icon: const Icon(Icons.send),
                  color: Theme.of(context).colorScheme.primary,
                  onPressed: _handleSendMessage,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState() {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.support_agent,
            size: 64,
            color: Theme.of(context).colorScheme.primary.withOpacity(0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'Служба поддержки Aman',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: Theme.of(context).colorScheme.onSurface,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'Задайте вопрос нашему виртуальному помощнику',
            style: TextStyle(
              fontSize: 14,
              color: Theme.of(context).colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMessageBubble(String message, bool isUser, DateTime time) {
    final timeString = _formatTime(time);
    
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment:
            isUser ? MainAxisAlignment.end : MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          if (!isUser)
            CircleAvatar(
              radius: 16,
              backgroundColor: Theme.of(context).colorScheme.primary,
              child: const Icon(
                Icons.support_agent,
                size: 18,
                color: Colors.white,
              ),
            ),
            
          const SizedBox(width: 8),
          
          Flexible(
            child: Container(
              padding: const EdgeInsets.symmetric(
                horizontal: 16,
                vertical: 12,
              ),
              decoration: BoxDecoration(
                color: isUser
                    ? Theme.of(context).colorScheme.primaryContainer
                    : Theme.of(context).colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(20),
                  topRight: const Radius.circular(20),
                  bottomLeft: Radius.circular(isUser ? 20 : 0),
                  bottomRight: Radius.circular(isUser ? 0 : 20),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    message,
                    style: TextStyle(
                      color: isUser
                          ? Theme.of(context).colorScheme.onPrimaryContainer
                          : Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    timeString,
                    style: TextStyle(
                      fontSize: 10,
                      color: isUser
                          ? Theme.of(context).colorScheme.onPrimaryContainer.withOpacity(0.7)
                          : Theme.of(context).colorScheme.onSurfaceVariant.withOpacity(0.7),
                    ),
                    textAlign: TextAlign.end,
                  ),
                ],
              ),
            ),
          ),
          
          const SizedBox(width: 8),
          
          if (isUser)
            CircleAvatar(
              radius: 16,
              backgroundColor: Theme.of(context).colorScheme.secondary,
              child: const Text(
                'Вы',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 10,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildTypingIndicator() {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          CircleAvatar(
            radius: 16,
            backgroundColor: Theme.of(context).colorScheme.primary,
            child: const Icon(
              Icons.support_agent,
              size: 18,
              color: Colors.white,
            ),
          ),
          const SizedBox(width: 8),
          Container(
            padding: const EdgeInsets.symmetric(
              horizontal: 16,
              vertical: 12,
            ),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.surfaceContainerHighest,
              borderRadius: const BorderRadius.only(
                topLeft: Radius.circular(20),
                topRight: Radius.circular(20),
                bottomRight: Radius.circular(20),
              ),
            ),
            child: Row(
              children: [
                _buildDot(0),
                _buildDot(1),
                _buildDot(2),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDot(int index) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 2),
      width: 8,
      height: 8,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        color: Theme.of(context).colorScheme.onSurfaceVariant.withOpacity(0.5),
      ),
      child: TweenAnimationBuilder<double>(
        tween: Tween(begin: 0.0, end: 1.0),
        duration: Duration(milliseconds: 400),
        builder: (context, value, child) {
          return Opacity(
            opacity: (index / 3 + value) % 1.0,
            child: child,
          );
        },
        child: Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Theme.of(context).colorScheme.onSurfaceVariant,
          ),
        ),
      ),
    );
  }

  void _showCallDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Позвонить в поддержку?'),
          content: const Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Горячая линия службы поддержки Aman:'),
              SizedBox(height: 16),
              Row(
                children: [
                  Icon(Icons.phone, color: Colors.green),
                  SizedBox(width: 8),
                  Text(
                    '+998 71 200 40 50',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 18,
                    ),
                  ),
                ],
              ),
              SizedBox(height: 16),
              Text(
                'Режим работы: ежедневно с 9:00 до 21:00',
                style: TextStyle(fontSize: 14),
              ),
            ],
          ),
          actions: <Widget>[
            TextButton(
              child: const Text('Отмена'),
              onPressed: () {
                Navigator.of(context).pop();
              },
            ),
            TextButton(
              child: const Text('Позвонить'),
              onPressed: () {
                Navigator.of(context).pop();
                // In a real app, this would initiate a phone call
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Звонок в службу поддержки...'),
                  ),
                );
              },
            ),
          ],
        );
      },
    );
  }

  String _formatTime(DateTime time) {
    final hour = time.hour.toString().padLeft(2, '0');
    final minute = time.minute.toString().padLeft(2, '0');
    return '$hour:$minute';
  }

  String _getFaqChipText(String question) {
    // Shorten the question for display in chips
    if (question.length > 25) {
      return '${question.substring(0, 22)}...';
    }
    return question;
  }
}
